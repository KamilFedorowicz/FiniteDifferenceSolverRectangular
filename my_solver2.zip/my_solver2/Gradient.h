#pragma once
#include <memory>
#include <vector>
#include "Grid.h"
#include "FieldTypes.h"

class Gradient{
public:
    
    static vectorField compute(
        const Grid& grid,
        const scalarField& scalField)
    {
        vectorField result(
            grid.get_ny(),
            std::vector<std::vector<double>>(grid.get_nx(), std::vector<double>(2, 0.0))
        );

        double dx = (grid.get_nx() > 1) ? (grid.get_x(1) - grid.get_x(0)) : 1.0;
        double dy = (grid.get_ny() > 1) ? (grid.get_y(1) - grid.get_y(0)) : 1.0;

        for (int i = 0; i < grid.get_ny(); ++i) {
            for (int j = 0; j < grid.get_nx(); ++j) {

                double d_dx = 0.0;
                double d_dy = 0.0;

                // --- df/dx ---
                if (grid.get_nx() > 1) {
                    if (j == 0) {
                        // forward difference
                        d_dx = (scalField[i][j + 1] - scalField[i][j]) / dx;
                    }
                    else if (j == grid.get_nx() - 1) {
                        // backward difference
                        d_dx = (scalField[i][j] - scalField[i][j - 1]) / dx;
                    }
                    else {
                        // central difference
                        d_dx = (scalField[i][j + 1] - scalField[i][j - 1]) / (2.0 * dx);
                    }
                }

                // --- df/dy ---
                if (grid.get_ny() > 1) {
                    if (i == 0) {
                        // forward difference
                        d_dy = (scalField[i + 1][j] - scalField[i][j]) / dy;
                    }
                    else if (i == grid.get_ny() - 1) {
                        // backward difference
                        d_dy = (scalField[i][j] - scalField[i - 1][j]) / dy;
                    }
                    else {
                        // central difference
                        d_dy = (scalField[i + 1][j] - scalField[i - 1][j]) / (2.0 * dy);
                    }
                }

                result[i][j][0] = d_dx;
                result[i][j][1] = d_dy;
            }
        }

        return result;
    }


    
    static scalarField return_nth_elem(const Grid& grid,
                                                            const std::vector<std::vector<std::vector<double>>>& field,
                                                            int n) {
        scalarField result(grid.get_ny(), std::vector<double>(grid.get_nx(), 0.0));
        for (int i = 0; i < field.size(); ++i) {
            for (int j = 0; j < field[0].size(); ++j) {
                result[i][j] = field[i][j][n];
            }
        }
        return result;
    }
    
    
private:
    
//    std::shared_ptr<Grid> grid;
    
    
};
